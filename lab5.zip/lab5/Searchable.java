package sc2002.lab5;
import java.util.List;
public interface Searchable {
    List<Book> searchBook(String keyword);
    
}
